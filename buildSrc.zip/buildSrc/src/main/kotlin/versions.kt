object Versions {
    const val COROUTINES = "1.7.3"
    const val STARTUP = "1.1.1"
    const val DATE_TIME = "0.5.0"
    const val TIMBER = "5.0.1"
    const val DAGGER = "2.49"
    const val HILT = "2.49"
    const val OK_HTTP = "4.12.0"
    const val RETROFIT = "2.9.0"
    const val MOSHI = "1.15.0"
    const val ROOM = "2.6.1"
}