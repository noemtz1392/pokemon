object ClassPath {
    const val HILT = "com.google.dagger:hilt-android-gradle-plugin:${Versions.HILT}"

}