object Project {
    const val MIN_SDK = 23
    const val TARGET_SDK = 34
    const val COMPILE_SDK = 34

    const val VERSION_CODE = 1
    const val VERSION_NAME = "1.0.0"
}